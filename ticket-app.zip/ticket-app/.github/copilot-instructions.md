# Instrucciones del proyecto

- Mantener la aplicación como un sitio estático de un solo archivo: `index.html`.
- Usar JavaScript vanilla, HTML y CSS sin frameworks ni build step.
- Conservar la interfaz en español y la persistencia mediante `localStorage`.
- Validar cambios abriendo `index.html` en un navegador moderno.
